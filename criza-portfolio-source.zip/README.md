# Criza Panuelos — portfolio

Buildless HTML, CSS and JavaScript. Serve the `dist` folder using any static server. All original portfolio imagery is stored locally as resized JPEGs. Fonts load from Google Fonts with local system fallbacks.

The supplied landing-page files were duplicates; only one is used. Six entries show four original deliverables (including related campaign assets) and two clearly labeled concept studies. Case-study commentary describes visible design decisions, not verified research or business results. Client testimonials are pending. Tools and skill levels have not been verified.

Contact setup: replace the contact note and download-only form handler in `dist/app.js` with a verified email or form service before using the site to receive inquiries. Add actual social profile URLs when supplied. The current form downloads a local brief and explicitly states that no message is sent.

Features: persisted dark/light mode, responsive navigation, category filtering, project search, accessible native-dialog previews, multi-image galleries, deep links to projects, reduced-motion support, scroll reveals, and a local project-brief download.
